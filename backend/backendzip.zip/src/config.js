const JWT_PASSWORD ="FutureFrameworks2024";
module.exports = { JWT_PASSWORD };